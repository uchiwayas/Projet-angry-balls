/**
 * R�solution num�rique d'une �quation � une inconnue r�elle, de la forme f(x) = 0
 * 
 *  avec f � valeurs dans R et x dans R
 */
/**
 * @author Dominique
 *
 */
package mesmaths.solveur;